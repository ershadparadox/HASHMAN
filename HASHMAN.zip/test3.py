# import subprocess

# dir_ = subprocess.getoutput("dir")

# print(dir_)

# import subprocess
# from colorama import Fore
# import os

# os.system("clear")

# while True:
#     cmd = input(Fore.WHITE+"shell==> ")
#     c = subprocess.check_output(cmd , shell=True)
#     print(c)

    
    
#     if cmd == "dir":
#         out1 = subprocess.getoutput("dir")
#         print(Fore.GREEN+out1)

        
